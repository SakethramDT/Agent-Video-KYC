import React, { useState } from 'react';
import AgentLogin from './components/AgentLogin';
import Header from './components/Header';
import StatsGrid from './components/StatsGrid';
import TabContainer from './components/TabContainer';
import './styles.css';
import { Download, Plus } from 'lucide-react';
import 'jspdf-autotable';

const App = () => {
  const [loggedInAgent, setLoggedInAgent] = useState(null);
   
  

  const getStatusBadgeStyle = (status) => {
    const baseStyle = {
      padding: '4px 8px',
      borderRadius: '9999px',
      fontSize: '12px',
      fontWeight: '500',
      display: 'inline-block'
    };

    switch (status) {
      case 'pending':
        return { ...baseStyle, backgroundColor: '#fef3c7', color: '#92400e' };
      case 'in-progress':
        return { ...baseStyle, backgroundColor: '#dbeafe', color: '#1e40af' };
      case 'completed':
        return { ...baseStyle, backgroundColor: '#d1fae5', color: '#065f46' };
      case 'rejected':
        return { ...baseStyle, backgroundColor: '#f2c9c9ff', color: '#222927ff' };
      case 'review':
        return {...baseStyle, backgroundColor: '#7acaf9ac'}
      default:
        return { ...baseStyle, backgroundColor: '#f3f4f6', color: '#374151' };
    }
  };

  const getRiskBadgeStyle = (risk) => {
    const baseStyle = {
      padding: '4px 8px',
      borderRadius: '9999px',
      fontSize: '12px',
      fontWeight: '500',
      display: 'inline-block'
    };

    switch (risk) {
      case 'low':
        return { ...baseStyle, backgroundColor: '#d1fae5', color: '#065f46' };
      case 'medium':
        return { ...baseStyle, backgroundColor: '#fef3c7', color: '#92400e' };
      case 'high':
        return { ...baseStyle, backgroundColor: '#fee2e2', color: '#991b1b' };
      default:
        return { ...baseStyle, backgroundColor: '#f3f4f6', color: '#374151' };
    }
  };

  const getAgentStatusDotStyle = (status) => {
    const baseStyle = {
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      display: 'inline-block'
    };

    switch (status) {
      case 'online':
        return { ...baseStyle, backgroundColor: '#10b981' };
      case 'busy':
        return { ...baseStyle, backgroundColor: '#f59e0b' };
      case 'offline':
        return { ...baseStyle, backgroundColor: '#6b7280' };
      default:
        return { ...baseStyle, backgroundColor: '#6b7280' };
    }
  };

   

  if (!loggedInAgent) {
    return <AgentLogin setLoggedInAgent={setLoggedInAgent} />;
  }

  return (
    <div className="kyc-container">
      <Header />
      <div className="kyc-main-content">
        <div className="kyc-page-header">
          <div>
            <h2 className="kyc-page-title">KYC Appilcations Dashboard</h2>
            <p className="kyc-page-subtitle" >View and manage all KYC (Know Your Customer) applications.</p>
            {/* <p className="kyc-page-subtitle">Welcome, {loggedInAgent}</p> */}
          </div>
          <div className="kyc-header-actions">
             
             
            <button
              onClick={() => setLoggedInAgent(null)}
              className="kyc-button logout-button"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              Logout
            </button>
          </div>
        </div>

        <StatsGrid 
        agent={loggedInAgent}
        />

        <TabContainer
          getStatusBadgeStyle={getStatusBadgeStyle}
          getRiskBadgeStyle={getRiskBadgeStyle}
          getAgentStatusDotStyle={getAgentStatusDotStyle}
           
          loggedInAgent={loggedInAgent}
        />
      </div>
    </div>
  );
};

export default App;